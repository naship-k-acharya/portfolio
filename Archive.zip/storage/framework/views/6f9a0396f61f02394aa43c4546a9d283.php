<?php $__env->startSection('pageClass', 'my-work'); ?>
<?php $__env->startSection('tabTitle', 'Sean McDonnell - Work'); ?>
<?php $__env->startSection('content'); ?>

<section class="my-work__section my-work__section--hero">
<h1>Work</h1>
<p style="text-align: center; margin-bottom: 0;"><img src="/images/my-work-hero.jpg"></p>
</section>
<section class="my-work__section my-work__section--1 my-work__section--edwrks">
    <div class="clear-fix">
        <div class="static static1">
            <div class="desc">
                <h2>EducationWorks</h2>
                <h3>Web Dev / UI</h3>
                <p>I like to work on the site design of non-profit project for Education Purpose.
                The primary goals were to creative an attractive, modern, mobile-friendly design, and
                reduce the number of pages through a tabbed content interface.</p>
                <a class="see-more" href="#" target="_blank">Take a Look</a>
            </div>
        </div>
        <div class="scroll-content">
            <div>
                <div style="position: relative; display: inline-block">
                    <img src="/images/educationworks-homepage.jpg">
                    <img class="mobile" width="150" src="/images/eduwo-phone.png">
                </div>
            </div>
            <img style="margin-top: 40px;" src="/images/educationworks-get-involved.jpg">
        </div>
    </div>
</section>
<section class="my-work__section my-work__section--2 my-work__section--powercorps">
    <div class="clear-fix">
        <div class="static static2">
            <div class="desc">
                <h2>Hotel Reservation Page</h2>
                <h3>Web Dev / UI</h3>
                <p>With a user-friendly interface and comprehensive search functionality, travelers can easily browse through a wide range of hotels, resorts, and vacation rentals to find the perfect stay for their needs. Our platform streamlines the booking process, allowing guests to secure their reservations with just a few clicks, while also providing access to exclusive deals and discounts.</p>
                <a class="see-more" href="#" target="_blank">Take a Look</a>
            </div>
        </div>
        <div class="scroll-content">
            <div style="position: relative; display: inline-block; margin-right: 100px;">
                <img style="margin-top: 0px;width: 600px;" src="/images/hotel0001.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0002.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0003.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0004.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0005.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0006.jpg">
                <img style="margin-top: 40px;width: 600px;" src="/images/hotel0007.jpg">
            </div>
        </div>
    </div>
</section>





<script type="text/javascript" src="/js/scripts.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nashipacharya/portfolioexam/resources/views/my-work.blade.php ENDPATH**/ ?>